package com.example.demo.controller;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.service.OpenApiService;
import com.example.demo.service.Test1_TTS;

@Controller
public class OpenApiController {
	
	@Autowired
	OpenApiService openApiService;
	
	@Autowired
	Test1_TTS test1_tts;
	
	
	@RequestMapping("getXY")
	@ResponseBody
	public String getXY(String address) {
		
		try {
			JSONObject jo=openApiService.getXY(address);
			System.out.println(jo);
			return jo.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "fail";
		}
		
	}
	
	@RequestMapping("tts")
	@ResponseBody
	public String tts(String text) {
		String name=test1_tts.tts(text);
		return name;
	}
	
	@RequestMapping("stt")
	@ResponseBody
	public String stt(String text) {
		System.out.println(text);
		if(text.contains("심심")) {
			return "나랑 같이 노래부를래?";
		}else {
			return "잘 못알아 들었어요.";
		}
	}
}
